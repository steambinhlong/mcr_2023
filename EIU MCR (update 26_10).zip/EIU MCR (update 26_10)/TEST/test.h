
#ifndef __TEST_H__
#define __TEST_H__


#define SW4	get_key(KEY3)
#define SW3	get_key(KEY2)
#define SW2	get_key(KEY1)
#define SW1	get_key(KEY0)
/*============================*/
/* Prototype declaration      */
/*============================*/
void test();

extern volatile unsigned char testing_flag;
#endif

/****************END FILE**************/

